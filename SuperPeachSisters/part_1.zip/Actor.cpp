#include "Actor.h"
#include "StudentWorld.h"

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp

//---------------------------
//ACTOR
Actor::Actor(int imageID, int startX, int startY, int dir, int depth, double size, StudentWorld* SW)
	: GraphObject(imageID, startX, startY, dir, depth, size), m_isDead(false), m_isDemagable(true), m_isPassable(true), m_StudentWorld(SW)
{
	

}
bool Actor::isPassable() {
	return m_isPassable;

}

bool Actor::isDamagable() {
	return m_isDemagable;
}

bool Actor::isDead() {
	return m_isDead;
}

void Actor::setDead(bool val) {
	m_isDead = val;
}

StudentWorld* Actor::getWorld() {
	return m_StudentWorld;
}

//---------------------------
//GROUND: base for Block and Pipe

Ground::Ground(int imageID, int startX, int startY, int dir, int depth, double size, StudentWorld* SW)
	: Actor(imageID, startX, startY, dir, depth, size, SW), m_hasGoodie(false)
{
}

void Ground::doSomething() {
	return;
}

void Ground::bonk() {
	if (!m_hasGoodie) {
		getWorld()->playSound(SOUND_PLAYER_BONK);
	}
	else {
		getWorld()->playSound(SOUND_POWERUP_APPEARS);
	}
}

bool Ground::isPassable() {
	return false;
}

bool Ground::isDamagable() {
	return false;
}
//---------------------------
//BLOCK

Block::Block(StudentWorld* SW, int startX, int startY)
	: Ground(IID_BLOCK, startX, startY, 0, 2, 1.0, SW)
{	
}

//----------------------------
//PIPE

Pipe::Pipe(StudentWorld* SW, int startX, int startY) 
	: Ground(IID_PIPE, startX, startY, 0, 2, 1.0, SW) 
{
}


//--------------------------------
//PEACH

Peach::Peach(StudentWorld* SW, int startX, int startY)
	: Actor(IID_PEACH, startX, startY, 0, 0, 1.0, SW), m_health(1)
{

}

void Peach::doSomething() {
	if (isDead()) {
		return;
	}
	else {
		int ch;
		int targetX;
		if (getWorld()->getKey(ch)) {
			switch (ch) {
			case KEY_PRESS_LEFT:
				setDirection(180);
				targetX = getX() - 4;
				if (!getWorld()->isBlockingObjectAt(targetX - SPRITE_WIDTH / 2, getY())) {
					moveTo(targetX, getY());
				}
				else {
					Actor* temp = nullptr;
					getWorld()->actorAt(targetX - SPRITE_WIDTH / 2, getY(), temp);
					temp->bonk();
				}
				break;
			case KEY_PRESS_RIGHT:
				setDirection(0);
				targetX = getX() + 4;
				if (!getWorld()->isBlockingObjectAt(targetX + SPRITE_WIDTH / 2, getY())) {
					moveTo(targetX, getY());
				}
				else {
					Actor* temp = nullptr;
					getWorld()->actorAt(targetX + SPRITE_WIDTH / 2, getY(), temp);
					temp->bonk();
				}
				break;
			}
		}
	}
}

void Peach::bonk() {
	return; //dummy
}