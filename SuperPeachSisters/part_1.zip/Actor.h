#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"


// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

class StudentWorld;

class Actor : public GraphObject {
public:
	Actor(int imageID, int startX, int startY, int dir, int depth, double size, StudentWorld* SW);
	void virtual doSomething() = 0;
	void virtual bonk() = 0;
	bool virtual isPassable();
	bool virtual isDamagable();
	bool isDead();
	void setDead(bool val);
	StudentWorld* getWorld();

private:
	int m_isDead;
	bool m_isDemagable;
	bool m_isPassable;
	StudentWorld* m_StudentWorld;

};
//---------------------------------------
//PEACH

class Peach : public Actor {
public:
	Peach(StudentWorld* SW, int startX, int startY);
	
	void virtual doSomething();

	void virtual bonk();

private:
	int m_health;
	

};


//base class for Block, pipe
// GROUND

class Ground : public Actor {
public:
	Ground(int imageID, int startX, int startY, int dir, int depth, double size, StudentWorld* SW);
	void virtual doSomething();
	void virtual bonk();
	bool virtual isPassable();
	bool virtual isDamagable();

private:
	bool m_hasGoodie;
};
//-----------------------------------------
//BLOCK

class Block : public Ground {
public:
	Block(StudentWorld* SW, int startX, int startY);
private:
};

//------------------------------------------
//PIPE

class Pipe : public Ground {
public:
	Pipe(StudentWorld* SW, int startX, int startY);
};
#endif // ACTOR_H_
