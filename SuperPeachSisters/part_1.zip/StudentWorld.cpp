#include "StudentWorld.h"
#include "GameConstants.h"
#include "Level.h"
#include <string>
#include <vector>
using namespace std;

GameWorld* createStudentWorld(string assetPath)
{
	return new StudentWorld(assetPath);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h, and Actor.cpp

StudentWorld::StudentWorld(string assetPath)
: GameWorld(assetPath)
{
}

StudentWorld::~StudentWorld() {
    cleanUp();
}

int StudentWorld::init()
{
    
    
    Level lev(assetPath());
    string level_file = "level01.txt";
    Level::LoadResult result = lev.loadLevel(level_file);
    if (result == Level::load_fail_file_not_found)
        return GWSTATUS_LEVEL_ERROR;
    else if (result == Level::load_fail_bad_format)
        return GWSTATUS_LEVEL_ERROR;
    else if (result == Level::load_success) {
        Level::GridEntry ge;
        for (int i = 0; i < GRID_WIDTH; i++) {
            for (int j = 0; j < GRID_HEIGHT; j++) {
                ge = lev.getContentsOf(i, j); // x=5, y=10
                switch (ge)
                {
                case Level::empty:
                
                    break;
                case Level::koopa:
                   
                    break;
                case Level::goomba:
                   
                    break;
                case Level::peach:
                    m_actors.push_back(new Peach(this, i * SPRITE_WIDTH, j * SPRITE_HEIGHT));
                    break;
                case Level::flag:
                    
                    break;
                case Level::block:
                    m_actors.push_back(new Block(this, i * SPRITE_WIDTH, j * SPRITE_HEIGHT));
                    break;
                case Level::pipe:
                    m_actors.push_back(new Pipe(this, i * SPRITE_WIDTH, j * SPRITE_HEIGHT));
                    break;
                case Level::star_goodie_block:
                
                    break;
                    
                }
            }
        }
       
    }
    return GWSTATUS_CONTINUE_GAME;

}

int StudentWorld::move()
{
    // This code is here merely to allow the game to build, run, and terminate after you hit enter.
    // Notice that the return value GWSTATUS_PLAYER_DIED will cause our framework to end the current level.
    for (int i = 0; i < m_actors.size(); i++) {
        m_actors[i]->doSomething();
    }
    
    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
    for (int i = 0; i < m_actors.size(); i++) {
        delete m_actors[i];
    }
    m_actors.erase(m_actors.begin(), m_actors.end());
}

bool StudentWorld::actorAt(int x, int y, Actor*& val) {

    vector<Actor*>::iterator it;
    it = m_actors.begin();
    while (it != m_actors.end()) {
        if (((*it)->getX() == x) && (*it)->getY() == y) {
            val = *it;
            return true;
        }
        it++;

    }
    return false;

}
bool StudentWorld::isBlockingObjectAt(int x, int y) {
    
    vector<Actor*>::iterator it;
    it = m_actors.begin();
    while (it != m_actors.end()) {
        if (((*it)->getX() == x) && (*it)->getY() == y) {
            return true;
        }
        it++;

    }
    return false;
    
}

bool StudentWorld::overlapLeft(Actor* a, Actor* b) {
    if ((a->getX() + (SPRITE_WIDTH - 1) > b->getX())) {
        return true;
    }
    if ((b->getX() + (SPRITE_WIDTH - 1) > a->getX())) {
        return true;
    }
    return false;

}

